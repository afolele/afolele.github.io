<?php


namespace WpLandingKit\Events;


class PluginActivated {

}