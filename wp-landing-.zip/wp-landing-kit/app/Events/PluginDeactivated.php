<?php


namespace WpLandingKit\Events;


class PluginDeactivated {

}