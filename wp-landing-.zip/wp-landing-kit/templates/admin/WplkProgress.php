<div class="WplkProgress" data-progress="0">
    <div class="WplkProgress__progress"></div>
    <div class="WplkProgress__background"></div>
    <div class="WplkProgress__percentage">0%</div>
</div>