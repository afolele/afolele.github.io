<?php


namespace WpLandingKit\Framework\Models;


use WpLandingKit\Framework\PostTypes\PostPostType;


class Post extends PostModelBase {


	const TYPE_CLASS = PostPostType::class;


}