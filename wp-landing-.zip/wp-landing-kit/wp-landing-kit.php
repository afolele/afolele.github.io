<?php
/**
 * Plugin Name: WP Landing Kit
 * Plugin URI:  https://wplandingkit.com/
 * Description: Create a landing page network by mapping domains to any post type
 * Version:     1.2.0
 * Author:      <a href="https://circa75.co/">Circa75</a> & <a href="https://hookturn.io">Hookturn</a>
 * Author URI:  https://wplandingkit.com/
 * Domain Path: /languages
 * Text Domain: wp-landing-kit
 */


// If this file is called directly, abort.
defined( 'ABSPATH' ) or die();


define( 'WP_LANDING_KIT_MIN_PHP_VERSION', 5.6 );
define( 'WP_LANDING_KIT_PLUGIN_VERSION', '1.2.0' );
define( 'WP_LANDING_KIT_PLUGIN_MAIN_FILE', __FILE__ );


// Require the main static class for starting the plugin
require 'app/Plugin.php';


// Require the API file for external use functions
require 'inc/api.php';


WpLandingKit\Plugin::start();