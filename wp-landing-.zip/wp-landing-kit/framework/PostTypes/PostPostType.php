<?php


namespace WpLandingKit\Framework\PostTypes;


class PostPostType extends PostTypeBase {


	const POST_TYPE = 'post';


}