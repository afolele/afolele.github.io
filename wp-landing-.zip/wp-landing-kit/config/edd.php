<?php

return [
	'item_name' => 'WP Landing Kit',
	'store_url' => 'https://wplandingkit.com/',
];