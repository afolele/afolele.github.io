<?php


namespace WpLandingKit\Framework\PostTypes;


class PagePostType extends PostTypeBase {


	const POST_TYPE = 'page';


}