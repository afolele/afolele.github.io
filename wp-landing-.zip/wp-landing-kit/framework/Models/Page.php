<?php


namespace WpLandingKit\Framework\Models;


use WpLandingKit\Framework\PostTypes\PagePostType;


class Page extends PostModelBase {


	const TYPE_CLASS = PagePostType::class;


}