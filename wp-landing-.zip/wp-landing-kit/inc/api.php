<?php
/**
 * API functions for the plugin.
 */


use WpLandingKit\Framework\Utils\Str;
use WpLandingKit\Framework\Utils\Url;
use WpLandingKit\Utils\Error;


/**
 * Insert a new domain into the database.
 *
 * @param string $domain_name The domain/hostname to register.
 * @param array|int $config Optional. Either a post ID or array of config data. If a post ID is provided, the root of
 *      the domain will be mapped to that post.
 *      e.g; [
 *           'enforce_protocol' => 'none',   // The protocol to enforce for this domain. Defaults to 'none'.
 *           'active' => false,              // Whether to activate this domain immediately. Defaults to FALSE.
 *           'owner_id' => 1234,             // The user ID who 'owns' this domain. Defaults to current user ID.
 *           'post_id' => 1234,              // The post ID to map the root of this domain to. Defaults to NULL.
 *      ]
 * @param bool $active Optional. Whether the domain should actively process requests. Note that the $options['active']
 *      value will take precedence over this, if present.
 *
 * @return WPLK_Domain|WP_Error
 */
function wplk_add_domain( $domain_name, $config = [], $active = false ) {
	// Handle WP_Post objects. Assume number is a post ID.
	if ( $config instanceof WP_Post ) {
		$config = [ 'post_id' => $config->ID ];

	} elseif ( is_numeric( $config ) ) {
		$config = [ 'post_id' => $config ];
	}

	$config = wp_parse_args( (array) $config, [
		'enforced_protocol' => '',
		'active' => $active,
		'owner_id' => get_current_user_id(),
		'post_id' => null,
	] );

	// Only allow the domain to be created in an active state if a post ID is present. Otherwise, there would be nothing
	// to map to.
	if ( $active and ! empty( $config['post_id'] ) ) {
		$config['active'] = true;
	}

	$domain = new WPLK_Domain( $domain_name );

	if ( ! empty( $config['post_id'] ) ) {
		$e = $domain->root()->maps_to_post( $config['post_id'] );
		if ( is_wp_error( $e ) ) {
			return $e;
		}
	}

	$is_active = $domain->set_is_active( $config['active'] );
	if ( is_wp_error( $is_active ) ) {
		return $is_active;
	}

	$domain->set_owner( $config['owner_id'] );
	$domain->set_enforced_protocol( $config['enforced_protocol'] );

	$saved = $domain->save();
	if ( is_wp_error( $saved ) ) {
		return $saved;
	}

	return $domain;
}


/**
 * Get an existing domain object.
 *
 * @param int|string $domain Either the domain post ID or the host name. Will also handle a full URL containing the host name.
 *
 * @return WPLK_Domain|null
 */
function wplk_get_domain( $domain ) {
	if ( $domain instanceof WPLK_Domain ) {
		return wplk_domain_exists( $domain->post_id() ) ? $domain : null;
	}

	return WPLK_Domain::get_instance( $domain );
}


/**
 * Check if a domain already exists in the database.
 *
 * @param string|int $domain Either the domain ID, host name, or URL containing the host name.
 *      e.g; 1234 or 'mydomain.com' or 'http://mydomain.com/some/path'
 *
 * @return bool
 */
function wplk_domain_exists( $domain ) {
	return WPLK_Domain::get_instance( $domain ) !== null;
}


/**
 * Check if an existing domain is active. Returns an error object if domain doesn't yet exist so to check existence of
 * a domain, use wplk_domain_exists().
 *
 * @param string|int|WPLK_Domain $domain Either the domain ID, instance, host name (mydomain.com), or URL containing
 *      host name (http://mydomain.com/path)
 *
 * @return bool|WP_Error Returns TRUE/FALSE if domain exists or WP_Error if domain can't be found on site.
 */
function wplk_domain_is_active( $domain ) {
	$domain = wplk_get_domain( $domain );

	if ( ! $domain instanceof WPLK_Domain ) {
		return Error::make( 'Could not check if domain was active — domain does not exist.' );
	}

	return $domain->is_active();
}


/**
 * Save the domain instance.
 *
 * @param WPLK_Domain $domain
 *
 * @return int|WP_Error
 */
function wplk_update_domain( WPLK_Domain $domain ) {
	return $domain->save();
}


/**
 * Map a full URL (containing the domain hostname) to a resource. This is a convenience function that determines the
 * domain and maps the specified resource to the path in the URL.
 *
 * This function does not support RegEx based URLs, term IDs, or post type arhive mappings. It only supports mapping
 * post IDs, WP_Post objects, and WP_Term objects to complete URLs. For more complex handling, use the `WPLK_Domain`'s
 * `add_mapping()` method in conjunction with the `WPLK_Mapping`'s methods.
 *
 * @param string $url The full URL, including the host name, to map to.
 * @param int|WP_Post|WP_Term $mapping Either a post ID, a WP_Post object, or a WP_Term object.
 *
 * @return WPLK_Domain|WP_Error
 */
function wplk_add_url( $url, $mapping ) {
	$domain = wplk_get_domain( $url );
	if ( $domain === null ) {
		return Error::make( 'Failed to map URL: %s. Could not find domain.', $url );
	}

	$path = Str::unleadingslashit( Url::make_relative( $url ) );
	if ( empty( $path ) ) {
		return Error::make( 'URL path is empty. This function cannot be used for root mappings.' );
	}

	$m = new WPLK_Mapping( $path );

	if ( ( is_numeric( $mapping ) or $mapping instanceof WP_Post ) and $post = get_post( $mapping ) ) {
		$m->maps_to_post( $post );

	} elseif ( $mapping instanceof WP_Term ) {
		$m->maps_to_term_archive( $mapping );

	} else {
		return Error::make( 'Failed to map URL: %s. Could not determine which resource to map to.', $url );
	}

	$domain->add_mapping( $m );
	$saved = $domain->save();

	return is_wp_error( $saved ) ? $saved : $domain;
}


/**
 * Delete a domain. This will remove a domain from the database entirely.
 *
 * @param string|int|WPLK_Domain $domain Either the domain ID, instance, host name (mydomain.com), or URL containing
 *      host name (http://mydomain.com/path)
 *
 * @return bool|WP_Error
 */
function wplk_delete_domain( $domain ) {
	$domain = wplk_get_domain( $domain );

	if ( ! $domain instanceof WPLK_Domain ) {
		return Error::make( 'Unable to delete domain at this time — domain was not found.' );
	}

	return $domain->delete();
}


/**
 * Activate a domain. If the domain cannot be activated, or if there is an error during activation, a WP_Error object
 * will be returned.
 *
 * @param string|int|WPLK_Domain $domain Either the domain ID, instance, host name (mydomain.com), or URL containing
 *      host name (http://mydomain.com/path)
 *
 * @return bool|WP_Error
 */
function wplk_activate_domain( $domain ) {
	$domain = wplk_get_domain( $domain );

	if ( ! $domain ) {
		return Error::make( 'Domain could not be located.' );
	}

	if ( ! $domain->can_activate() ) {
		return Error::make( 'Domain cannot be activated at this time.' );
	}

	if ( is_wp_error( $active = $domain->activate() ) ) {
		return $active;
	}

	if ( is_wp_error( $id = $domain->save() ) ) {
		return $id;
	}

	return $domain->is_active();
}


/**
 * Deactivate a domain. If the domain cannot be activated, or if there is an error during activation, a WP_Error object
 * will be returned.
 *
 * @param string|int|WPLK_Domain $domain Either the domain ID, instance, host name (mydomain.com), or URL containing
 *      host name (http://mydomain.com/path)
 *
 * @return bool|WP_Error
 */
function wplk_deactivate_domain( $domain ) {
	$domain = wplk_get_domain( $domain );

	if ( ! $domain ) {
		return Error::make( 'Domain could not be located.' );
	}

	$domain->deactivate();

	if ( is_wp_error( $id = $domain->save() ) ) {
		return $id;
	}

	return ! $domain->is_active();
}