<?php


namespace WpLandingKit\Exceptions;


use Exception;


class LicenseActivationException extends Exception {

}